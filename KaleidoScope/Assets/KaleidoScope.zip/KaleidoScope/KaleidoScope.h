//
//  KaleidoScope.h
//  KaleidoScope
//
//  Created by shoichiyamazaki on 2018/08/16.
//  Copyright © 2018年 shoichiyamazaki. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KaleidoScope.
FOUNDATION_EXPORT double KaleidoScopeVersionNumber;

//! Project version string for KaleidoScope.
FOUNDATION_EXPORT const unsigned char KaleidoScopeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KaleidoScope/PublicHeader.h>


